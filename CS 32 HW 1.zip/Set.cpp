#include "Set.h"

Set::Set()
{
	m_setSize = 0;
}

bool Set::empty() const
{
	if (m_setSize == 0)
	{
		return true;
	}
	else
		return false;
}

int Set::size() const
{
	return m_setSize;
}

bool Set::insert(const ItemType& value)
{
	if (m_setSize == DEFAULT_MAX_ITEMS || contains(value))
	{
		return false;
	}

	collection[m_setSize] = value;
	m_setSize++;
	return true;
}

bool Set::erase(const ItemType& value)
{
	if (m_setSize == 0)
	{
		return false;
	}
	for (int i = 0; i < m_setSize; i++)
	{
		if (collection[i] == value)
		{
			collection[i] = collection[m_setSize - 1];
			m_setSize--;
		}
	}
}


bool Set::contains(const ItemType& value)
{
	if (m_setSize == 0)
	{
		return false;
	}

	for (int i = 0; i < m_setSize; i++)
	{
		if (collection[i] == value)
		{
			return true;
		}
	}

	return false;
}

bool Set::get(int i, ItemType& value) const
{
	if (empty())
	{
		return false;
	}

	if (i >= 0 && i < m_setSize)
	{
		value = collection[i];
		return true;
	}

	return false;
}

void Set::swap(Set& other)
{
	int largest = 0;
	if (this->size() > other.size())
	{
		largest = this->size();
	}
	else
	{
		largest = other.size();
	}
	for (int i = 0; i < largest; i++)
	{
		ItemType temp = this->collection[i];
		this->collection[i] = other.collection[i];
		other.collection[i] = temp;
	}

	return;
}
