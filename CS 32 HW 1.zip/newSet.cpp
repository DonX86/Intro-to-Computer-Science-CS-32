#include "newSet.h"

Set::Set()
{
	maxSize = DEFAULT_MAX_ITEMS;
	m_setSize = 0;
	collection = new ItemType[DEFAULT_MAX_ITEMS];
}

Set::Set(int n)
{
	maxSize = DEFAULT_MAX_ITEMS;
	m_setSize = 0;
	collection = new ItemType[n];
}

Set::~Set()
{
	delete[] collection;
}

Set::Set(Set& other)
{
	delete[] this->collection;
	m_setSize = other.size();
	collection = new ItemType[other.maxSize];
	for (int i = 0; i < other.size(); i++)
	{
		collection[i] = other.collection[i];
	}
}

Set& Set::operator=(const Set& other)
{
	if (&other == this)
	{
		return *this;
	}

	delete[] this->collection;
	m_setSize = other.size();
	collection = new ItemType[maxSize];
	for (int i = 0; i < other.size(); i++)
	{
		collection[i] = other.collection[i];
	}

}

bool Set::empty() const
{
	if (m_setSize == 0)
	{
		return true;
	}
	else
		return false;
}

int Set::size() const
{
	return m_setSize;
}

bool Set::insert(const ItemType& value)
{
	if (m_setSize == DEFAULT_MAX_ITEMS)
	{
		return false;
	}

	collection[m_setSize] = value;
	m_setSize++;
	return true;
}

bool Set::erase(const ItemType& value)
{
	if (m_setSize == 0)
	{
		return false;
	}
	for (int i = 0; i < m_setSize; i++)
	{
		if (collection[i] == value)
		{
			collection[i] = collection[m_setSize - 1];
			m_setSize--;
		}
	}
}


bool Set::contains(const ItemType& value)
{
	if (m_setSize == 0)
	{
		return false;
	}

	for (int i = 0; i < m_setSize; i++)
	{
		if (collection[i] == value)
		{
			return true;
		}
	}
}

bool Set::get(int i, ItemType& value)
{
	if (empty())
	{
		return false;
	}

	if (i >= 0 && i < m_setSize)
	{
		value = collection[i];
		return true;
	}

	return false;
}


void Set::swap(Set& other)
{
	ItemType* temp = this->collection;
	this->collection = other.collection;
	other.collection = temp;

	int temp2 = this->size();
	this->m_setSize = other.size();
	other.m_setSize = temp2;

	int temp3 = this->maxSize;
	this->maxSize = other.maxSize;
	other.maxSize = temp3;

	return;
}