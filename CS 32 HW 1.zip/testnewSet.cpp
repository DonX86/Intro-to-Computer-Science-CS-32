#include <iostream>
#include "newSet.h"
using namespace std;

int main()
{
	Set s;
	s.insert(11111111);
	s.insert(22323546);
	s.insert(1234);
	s.insert(5678);
	s.insert(7869);
	s.insert(8980);
	s.insert(12345);
	s.insert(1236);
	s.insert(12345);

	if (s.contains(1234))
	{
		cout << "yes" << endl;
	}

	cout << endl;
	if (!s.empty())
	{
		cout << "not empty" << endl;
		cout << "Size equals " << s.size() << endl;
	}

	ItemType t;

	cout << endl;
	for (int i = 0; i < s.size(); i++)
	{
		s.get(i, t);
		cout << t << endl;
	}

	s.erase(1234);

	cout << endl;
	for (int i = 0; i < s.size(); i++)
	{
		s.get(i, t);
		cout << t << endl;
	}

	Set s2;
	s2.insert(9999);
	s2.insert(7878);
	s2.insert(8567);
	s2.insert(1234556);
	s2.insert(1342435);

	s.swap(s2);

	cout << endl;
	for (int i = 0; i < s.size(); i++)
	{
		s.get(i, t);
		cout << t << endl;
	}
	cout << endl << "size equals " << s.size() << endl;

	cout << endl;
	for (int i = 0; i < s.size(); i++)
	{
		s2.get(i, t);
		cout << t << endl;
	}
	cout << endl << "size equals " << s2.size() << endl;

	system("pause");
	return 0;
}
