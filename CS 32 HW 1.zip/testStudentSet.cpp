#include <iostream>
#include "StudentSet.h"
using namespace std;

int main()
{
	StudentSet ss;
	ss.add(12334);
	ss.add(62338);
	ss.add(6983488);
	ss.add(7777777);
	ss.add(9865353);
	ss.add(1000221);
	ss.add(7890000);
	ss.add(7897979);
	ss.add(7890000);

	cout << ss.size() << endl << endl;

	ss.print();

	system("pause");
	return 0;
}
