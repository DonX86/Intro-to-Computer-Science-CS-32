#include "StudentSet.h"
#include <iostream>

StudentSet::StudentSet()
{}

bool StudentSet::add(unsigned long id)
{
	return students.insert(id);
}

int StudentSet::size() const
{
	return students.size();
}

void StudentSet::print() const
{
	ItemType value = 0;

	for (int i = 0; i < students.size(); i++)
	{
		students.get(i, value);
		std::cout << value << std::endl;
	}
	return;
}
